// api/contact.js
// Vercel Serverless Function — POST /api/contact

// In-memory store (resets on cold start, enough for demos)
// For permanent storage, add MongoDB Atlas free tier later
const messages = [];

export default function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // ── POST: Save message ──
  if (req.method === 'POST') {
    const { name, email, message } = req.body || {};

    if (!name || !email || !message) {
      return res.status(400).json({
        success: false,
        message: 'Naam, email aur message zaroori hain!'
      });
    }

    if (!email.includes('@')) {
      return res.status(400).json({
        success: false,
        message: 'Sahi email likhen!'
      });
    }

    const entry = {
      id: Date.now().toString(),
      name: name.trim(),
      email: email.trim(),
      message: message.trim(),
      createdAt: new Date().toISOString()
    };

    messages.push(entry);
    console.log(`New message from: ${name} (${email})`);

    return res.status(200).json({
      success: true,
      message: 'Message mil gaya! Huzaifa jald reply karega 🙌'
    });
  }

  // ── GET: View messages ──
  if (req.method === 'GET') {
    return res.status(200).json({
      success: true,
      total: messages.length,
      data: messages
    });
  }

  return res.status(405).json({ success: false, message: 'Method not allowed' });
}
